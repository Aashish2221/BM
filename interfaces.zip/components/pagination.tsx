import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import { MdArrowBackIos, MdArrowForwardIos } from 'react-icons/md';

type Props ={
    query:any;
}
const Pagignation = ({query}:Props) => {
    
}

export default Pagignation