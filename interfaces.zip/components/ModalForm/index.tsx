import Modal from "./Modal";
export { Modal as RegisterLoginModal };
