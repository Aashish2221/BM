
export default function productListing() {
  
  return (
    <div>
      <div className="ml-20">
        <h1 className="text-2xl font-medium">Product Listing Page</h1>
        
        <div className="mr-20 ml-20 mt-20 max-w-7xl">
        <p className="indent-8">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ad, iste.
          Dicta enim possimus perspiciatis ea, suscipit ad! A fugit ipsa
          accusantium autem odio exercitationem quibusdam at repellendus. Modi,
          voluptatum tempora!Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ad, iste.
          Dicta enim possimus perspiciatis ea, suscipit ad! A fugit ipsa
          accusantium autem odio exercitationem quibusdam at repellendus. Modi,
          voluptatum tempora!suscipit ad! A fugit ipsa
          accusantium autem odio exercitationem quibusdam at repellendus. Modi,
          voluptatum tempora!
        </p>
      </div>
      </div>
    </div>
  );
}