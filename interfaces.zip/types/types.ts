export interface spotPriceInterface {
  gold: number;
  silver: number;
  goldChange: number;
  silverChange: number
  goldBid: number;
  silverBid: number;
  goldChangePercent: number;
  silverChangePercent: number;
}
