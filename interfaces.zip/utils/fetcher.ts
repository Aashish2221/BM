import axios from "axios";

const fetcher = axios.create();

export default fetcher;
